using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire : MonoBehaviour
{
  public void DestroyThis()
    {
        Destroy(this.gameObject);
    }
}
