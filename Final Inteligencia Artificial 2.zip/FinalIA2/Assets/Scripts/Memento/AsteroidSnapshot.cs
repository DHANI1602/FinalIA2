﻿using UnityEngine;

public class AsteroidSnapshot
{
    public Vector3 pos;
}
