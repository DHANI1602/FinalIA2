﻿using UnityEngine;

public class PlayerSnapshot
{
    public Vector3 pos;
    public Quaternion rot;
}
