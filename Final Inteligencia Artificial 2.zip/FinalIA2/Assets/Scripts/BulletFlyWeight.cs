﻿
public class BulletFlyWeight 
{
    public  float projectilespeed;
}
