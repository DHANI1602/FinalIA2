﻿

public class AsteroidFlyWeight
{
    public int scoreflyweight;
}
