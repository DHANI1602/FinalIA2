﻿
public class BulletFlyweightPointer
{
    public static BulletFlyWeight bulletFlyweight = new BulletFlyWeight{projectilespeed = 300f};
}
