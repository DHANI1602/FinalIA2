﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerModel : MonoBehaviour
{
    public float turnInput;
    public float timetoshoot;
    public float timetoshoot1;

    public Transform fireposition;
    public GameObject[] motorfire;

    public WeaponHandler WH;
    public GameObject laser;

    public CircleQuery query;

    public bool isAlive;

}
