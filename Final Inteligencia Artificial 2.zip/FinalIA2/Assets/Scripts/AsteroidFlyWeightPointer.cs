﻿public class AsteroidFlyweightPointer
{
    public static AsteroidFlyWeight asteroidflyweight = new AsteroidFlyWeight { scoreflyweight = 17 };
}
